#! /home/users/baumgart/bin/swipl -G16M -L32M -q -t main -f

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 
%%%% Yarralumla -
%%%% Yet another range restriction avoiding loops under much less assumptions
%%%% 
%%%% Author: Peter Baumgartner, National ICT Australia
%%%% http://rsise.anu.edu.au/~baumgart/
%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- use_module('/home/users/baumgart/prover/yarralumla/lib/pretty').
:- use_module('/home/users/baumgart/prover/yarralumla/lib/fromonto').
:- use_module('/home/users/baumgart/prover/yarralumla/misc').
:- use_module('/home/users/baumgart/prover/yarralumla/data_structures').
:- use_module('/home/users/baumgart/prover/yarralumla/flattening').
:- use_module('/home/users/baumgart/prover/yarralumla/shifting').
:- use_module('/home/users/baumgart/prover/yarralumla/separation').
:- use_module('/home/users/baumgart/prover/yarralumla/range_restriction').
:- use_module('/home/users/baumgart/prover/yarralumla/blocking').
:- use_module('/home/users/baumgart/prover/yarralumla/subsumption').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

main :-
        catch(( process_argv(InputFile, OutputFile), 
	        process_file(InputFile, OutputFile)
	      ), 
	      E, (print_message(error, E), fail)),
        halt.                                           
main :- 
	usage.

usage :-
	msg('Usage: yarralumla.pl [Option...] File[.tme]'),
	msg('Options:'),
	msg('  --flattening none|standard|separation'),
	msg('  --flatteningextractconstants true|false'),
	msg('  --flattenhead true|false'),
	msg('  --flattentoplevel true|false'),
	msg('  --flattenequations true|false'),
	msg('  --shifting false|true'),
	msg('  --separation none|nonequations|full'),
	msg('  --rangerestriction true|false'),
	msg('  --blocking false|true'),
	msg('Output will be written to FILE-yarr.tme'),
        halt(1).

process_argv(InputFile, OutputFile) :-
	current_prolog_flag(argv, Argv), 
	append(_, [--|Args], Argv),
	!,
	parameter('--blocking', [false, true], Blocking, Args),
	parameter('--flattening', [none, standard, separation], Flattening, Args),
	parameter('--flatteningextractconstants', [true, false], Flatteningextractconstants, Args),
	parameter('--flattenhead', [true, false], Flattenhead, Args),
	parameter('--flattentoplevel', [true, false], Flattentoplevel, Args),
	parameter('--flattenequations', [true, false], Flattenequations, Args),
	parameter('--separation', [none, nonequations, full], Separation, Args),
	parameter('--shifting', [false, true], Shifting, Args),
	parameter('--rangerestriction', [true, false], Rangerestriction, Args),
	%% Ugly: options are held in global variables
	%% Clumsy: passing around options
%% Sorting currently disabled:
	nb_setval(sorting_option, false),
	nb_setval(blocking_option, Blocking),
	nb_setval(flattening_option, Flattening),
	nb_setval(flatteningextractconstants_option, Flatteningextractconstants),
	nb_setval(flattenhead_option, Flattenhead),
	nb_setval(flattentoplevel_option, Flattentoplevel),
	nb_setval(flattenequations_option, Flattenequations),
	nb_setval(rangerestriction_option, Rangerestriction),
	nb_setval(separation_option, Separation),
	nb_setval(shifting_option, Shifting),
	get_regular_arg(Args, File),
	basename(File, '.tme', FileBase),
	atom_concat(FileBase,'.tme', InputFile),
	atom_concat(FileBase,'-yarr.tme', OutputFile).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

process_file(InputFile, OutputFile) :-
	msg('Reading ~w ...', [InputFile]),
	file_clauses(InputFile, CS),
	length(CS, Len),
	msg('~d clauses.', [Len]),
	process_clause_set(CS, CSRes),
	msg('Writing ~w ...', [OutputFile]),
	onto_file(( member(C, CSRes),
%% 	            write_canonical(C), writeln('.'),  
	            pp_clause(C),
%% 	            write(C), writeln('.'),  
	            fail
	          ; true 
	          ), OutputFile)
	      ,
	msg('Done.').

process_clause_set(CS, CSRes) :-
	maplist(to_list_clause, CS, LCS1),
	( nb_getval(flattening_option, none) ->
	    LCS2 = LCS1
	; flatten_clause_set(LCS1, LCS2)
        ),
	( nb_getval(shifting_option, false) ->
	    LCS3 = LCS2
	; shift_clause_set(LCS2, LCS3)
        ),
	( nb_getval(separation_option, false) ->
	    LCS4 = LCS3
	; separation_clause_set(LCS3, LCS4)
        ),
	( nb_getval(rangerestriction_option, false) -> 
	    LCS5 = LCS4
	; rr_clause_set(LCS4, LCS5)
        ),
	( nb_getval(blocking_option, false) -> 
	    LCS6 = LCS5
	; %% blocking is on. Sanity check the flags:
	  ( nb_getval(rangerestriction_option, false) ->
	      msg('WARNING: blocking is on but range restriction is off.',[])
	  ; true 
          ),
	  blocking_clause_set(LCS5, LCS6)
        ),
	%% simplify(LCS6, CSRes),
	maplist(from_list_clause, LCS6, CSRes).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Misc code: file handling, argument analysis

file_clauses(File, Clauses) :-
	from_file(findall(T,
			  ( repeat,
			    read(T),
			    ( T == end_of_file ->
				!,
		              fail
			    ; true
			    )
			  ),
			  Clauses),
		  File).

basename(FileName, Extension, FileBaseName) :-
	%% FileName does end in extension:
	atom_concat(FileBaseName,Extension,FileName), !.
basename(FileName, _Extension, FileName).
	%% Otherwise the basename is the given FileName.


parameter(Parameter, LegalValues, Value, Args) :-
	append(_,[Parameter, Value|_], Args), !,
	%% Yes, Parameter is given, check for legal value:
	memberchk(Value, LegalValues).
parameter(_Parameter, [DefaultValue|_MoreLegalValues], DefaultValue, _Args).

get_regular_arg([Arg], Arg) :-
	%% In case of a single arg it is easy:
	\+ is_option(Arg).
get_regular_arg(Args, Arg) :-
	%% otherwise look at last two arguments
	append(_, [A,Arg], Args),
	\+ is_option(A), %% because otherwise Arg would be an argument
	                 %% to option A
	\+ is_option(Arg).


is_option(N) :- sub_atom(N, 0, 2, _, '--').


