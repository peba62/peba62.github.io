
/*
 * Subsumption tests on clauses and sets of clauses,
 *
 * by Peter Baumgartner
 * Last change: 1/2/2006:
 *  - ported as a module to SWI prolog
 *  - representation: works with list clauses now 
 *    (clauses of the form H :- B where H and B are lists of atoms) 
 *    instead of literal lists
 * Initial version: 6/2/1998
 */ 

:- module(subsumption, [subsumption_filter/2]).

% subsumption_filter(CS,CSSubs)
% CS is a list of clauses, CSSubs is a maximal subset of CS such that no two different 
% clauses in CSSubs subsume each other.
subsumption_filter(CS,CSSubs) :-
	subsumption([],CS,CSSubs).

% subsumption(CDone,COpen,CRes)
% The whole clause set is presented as CDone \cup COpen
% CDone is the list of clauses which are mutually checked for subsumption
% COpen is not yet checked.
% CRes is the union of these sets, but subsumed clauses deleted
subsumption(CDone,[],CDone).
subsumption(CDone,[F|R],CRes) :-
	subsumption_one_clause(CDone,F,CDoneWithF),
	subsumption(CDoneWithF,R,CRes).

% subsumption_one_clause(CDone,C,CRes). 
% CDone is a list of clauses (which is closed wrt. subsumption)
% C is a clause
% CRes is CDone if C is subsumed by some clause in CDone
% otherwise CRes includes C and all subsumed clauses (by C) are removed.
subsumption_one_clause(CDone,C,CDone) :-
	%% forward subsumption:
	%% member(CD,CDone), 
	%% s_subsumes(([H] :- [])CD,C), !.
	%% Try: for efficiency reasons, restrict to facts:
	member(([H] :- []),CDone), 
	s_subsumes(([H] :- []),C), !.
subsumption_one_clause(CDone,C,[C|CDel]) :-
	%% backward subsumption
	%% here we know that C is not subsumed by any clause in CDone
	delete_subsumed(CDone,C,CDel).
% some more filters : condensement, tautologies,...?

delete_subsumed([],_C,[]).
delete_subsumed([F|R],C,RRes) :-
	s_subsumes(C,F), !,
	delete_subsumed(R,C,RRes).
delete_subsumed([F|R],C,[F|RRes]) :-
	delete_subsumed(R,C,RRes).

% s_subsumes(C1,C2): Does clause C1 subsume clause C2?
% e.g. [p(X)] s_subsumes [p(f(X)),q(b)]
% clauses may share variables - they are renamed before.
% s_subsumes does no instantiation
s_subsumes(C1,C2) :-
	\+ \+ (
	copy_term(C2,C2C),
	term_variables(C2C,C2CVs),
	s_skolemize(C2CVs),
	s_subsumes_(C1,C2C), !
	).

% like s_subsumes, but assumes that C2 is ground already
%% Code for the literal list representation of clauses:
s_subsumes_([],_C2).
% optional case:
s_subsumes_([C1F|C1R],C2) :-
	s_memberq(C1F,C2), !, 
	s_subsumes_(C1R,C2).
s_subsumes_([C1F|C1R],C2) :-
	member(C1F,C2), 
	s_subsumes_(C1R,C2).

%% Code for the list clause representation of clauses.
%% The previous code can easily be re-used:
s_subsumes_((H1 :- B1), (H2 :- B2)) :-
	s_subsumes_(H1, H2),
	s_subsumes_(B1, B2).
	

s_skolemize(VarList) :-
	s_skolemize(VarList,1).

s_skolemize([],_Nr).
s_skolemize([sk(Nr)| MoreVars],Nr) :-
	NNr is Nr + 1,
	s_skolemize(MoreVars,NNr).


s_memberq(HArg,[Arg|_]) :-
        HArg == Arg, !.
s_memberq(Arg,[_|Tail]) :-
        s_memberq(Arg,Tail).

/*
 * tests:
 *
s_subsumes([p(X)],[p(a)]) -> success
s_subsumes([p(X)],[p(f(X))]) -> success
s_subsumes([p(f(X))],[p(X)]) -> fail
s_subsumes([p(X),q(X)],[p(a),q(X)]) -> fail
s_subsumes([p(X),q(X)],[p(a),q(a)]) -> success
s_subsumes([p(X),q(X)],[q(a),p(a),r(a)]) -> success
 *
C1 = [p(X)], C2 = [p(a),p(b)], C3 = [p(X),p(a)], subsumption_filter([C1,C2,C1,C3],S) ->
 S = [[p(X)]]
*/