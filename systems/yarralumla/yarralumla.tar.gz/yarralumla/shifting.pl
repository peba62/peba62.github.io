%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% Shifting
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(shifting, [shift_clause_set/2]).

:- use_module('/home/users/baumgart/prover/yarralumla/misc').
:- use_module('/home/users/baumgart/prover/yarralumla/data_structures').


shift_clause_set(CS, Res) :-
	%% Ugly: global variable:
	set_create(not_predicate_symbols),
	%% Do the shifting:
	maplist(shift_clause, CS, CSTS),
	%% CS and CSTS are sets of list clauses.
	%% Generate consistency axioms for the shifted predicates:
	set_members(not_predicate_symbols, PredicateSymbols),
	consistency_clauses(PredicateSymbols, ConsistencyClauses),
	append(CSTS, ConsistencyClauses, Res).


shift_clause((H :- B), (HTS :- BOther)) :-
	atoms_with_proper_subterms(B, BProperSubTerms, BOther),
	prepend_atoms_predsyms(BProperSubTerms, 'not_', 
	                       BProperSubTermsNot, Sig),
	remember_functors(not_predicate_symbols, Sig),
	append(H, BProperSubTermsNot, HTS).


%% atoms_with_proper_subterms(B, BProperSubTerms, BOther)
%% BProperSubTerms is exactly those elements of B that contain
%% at least one proper functional term (i.e. a term that is neither 
%% a constant nor a variable). The remaining ones are in BOther

atoms_with_proper_subterms([], [], []).
atoms_with_proper_subterms([A|R], [A|RProperSubTerms], ROther) :-
	args(A, AArgs),
	member(T, AArgs), 
	compound(T),
	atoms_with_proper_subterms(R, RProperSubTerms, ROther).
atoms_with_proper_subterms([A|R], RProperSubTerms, [A|ROther]) :-
	atoms_with_proper_subterms(R, RProperSubTerms, ROther).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Make clauses expressing consistency of "not_p"-atoms and "p"-atoms:

consistency_clauses([], []).
consistency_clauses([P/N|R], [([] :- [B1,B2])|RRes]) :-
	make_N_variables(N, NVars),
	B1 =.. [P|NVars],
	concat_atom(['not_',P], NotP),
	B2 =.. [NotP|NVars],
	consistency_clauses(R, RRes).




