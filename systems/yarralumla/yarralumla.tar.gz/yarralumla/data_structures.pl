%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% Data Structures
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(data_structures,
        [subst_domain/2,
	 subst_range/2,
	 subst_codomain/2,
	 apply_subst/3,
	 clause_atoms/2,
	 list_clause/2,
	 to_list_clause/2,
	 from_list_clause/2,
	 args/2,
	 terms_args_union/2,
	 simplify/2,
	 make_equations/3,
	 make_N_variables/2,
	 add_argument/3,
	 add_arguments/3,
	 prepend_atoms_predsyms/4,
	 scan_function_symbols/2,
	 scan_predicate_symbols/2,
	 scan_dom_functors/2,
	 p_atoms/3,
	 make_unify/3
      ]).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Select one:
%% make_unify(L,R,(L=R)).
make_unify(L,R,yarr_unify(L,R)).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subst_var((X/_T), X).
subst_term((_X/T), T).

subst_domain(Subst, Domain) :-
	maplist(subst_var, Subst, Domain).
subst_range(Subst, Range) :-
	maplist(subst_term, Subst, Range).
subst_codomain(Subst, Codomain) :- 
	subst_range(Subst, Range),
	term_variables(Range, Codomain).


%% apply_subst(Subst, Term, Instance)
%% Apply a substitution Subst to a term Term, giving the instance Instance.
%% WARNING: limited applicability, will apply subst just to arguments:
apply_subst(Subst, Term, Instance) :-
	Term =.. [Fun|Args],
	apply_subst_to_args(Subst, Args, ArgsInstances),
	Instance =.. [Fun|ArgsInstances].

apply_subst_to_args(_Subst, [], []).
apply_subst_to_args(Subst, [Y|R], [T|RRes]) :-
	member(X/T, Subst), X == Y, !, 
	apply_subst_to_args(Subst, R, RRes).
apply_subst_to_args(Subst, [T|R], [T|RRes]) :-
	apply_subst_to_args(Subst, R, RRes).

clause_atoms((H :- B), Atoms) :-
	append(H, B, Atoms).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Representation of clauses throughout most parts of this code is as
%% "list clauses":
%% A "list clause" has the form H :- B where H and B are (possibly empty)
%% lists of atoms.
%% E.g., the clause 'p ; q :- r, s' as a *list clause* is [p,q] :- [r,s] . 

list_clause(Clause,ListClause) :-
	( nonvar(Clause) ->
	    to_list_clause(Clause,ListClause)
	;   from_list_clause(ListClause,Clause)
        ).

to_list_clause((H :- B), (HL :- BL)) :-
	!,
	dis_to_list(H,HL),
	con_to_list(B,BL).
to_list_clause(H, (HL :- [])) :-
	%% Clause without a body
	dis_to_list(H,HL).

from_list_clause((H :- []), HC) :- !, 
	list_to_dis(H, HC).
from_list_clause((H :- B), (HC :- BC)) :-
	list_to_dis(H, HC),
	list_to_con(B, BC).


con_to_list( (true, L), PL_L ) :- con_to_list(L, PL_L), !.
con_to_list( (K, L), [K | PL_L] ) :- con_to_list(L, PL_L), !.
con_to_list( true, [] ) :- !.
con_to_list( K, [K] ).

dis_to_list( (false; L), PL_L ) :- dis_to_list(L, PL_L), !.
dis_to_list( (K; L), [K | PL_L] ) :- dis_to_list(L, PL_L), !.
dis_to_list( false, [] ) :- !.
dis_to_list( K, [K] ).


list_to_dis([], false).
list_to_dis([L], L) :- !.
list_to_dis([L|R], (L ; R_D)) :- list_to_dis(R, R_D).

list_to_con([], true).
list_to_con([L], L).
list_to_con([L|R], (L , R_C)) :- list_to_con(R, R_C).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% terms_args_union(TermsList, ArgsUnion)
%% ArgsUnion is the list of terms of all the argument terms
%% of all the terms in TermList (TermList os typically a list of atoms)
terms_args_union(TermsList, ArgsUnion) :-
	maplist(args, TermsList, ArgsLists),
	append(ArgsLists, ArgsUnion).

args(Term, Args) :-
	Term =.. [_Pred|Args].

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Simplify a set of list clauses CS.
%% We currently do only simplification of clauses by unit resolution with
%% positive ground unit clauses
simplify(CS, CSS) :-
	sublist(pguc, CS, PGUCs), %% get the positive unit clauses
	sublist(non_pguc, CS, NonPGUCs), %% get the other clauses
	findall(CSimp,
	        ( member(C, NonPGUCs),
		  pguc_simplify(PGUCs, C, CSimp)
	        ),
		CSS).
	
%% Simplify a clause by a set of positive ground unit clauses
pguc_simplify(PGUCs, (H :- B), (H :- BRes)) :-
	pguc_simplify_body(PGUCs, B, BRes).

pguc_simplify_body(_PGUCs, [], []).
pguc_simplify_body(PGUCs, [A|B], BRes) :-
	member(([H] :- []), PGUCs), H == A, !,
	pguc_simplify_body(PGUCs, B, BRes).
pguc_simplify_body(PGUCs, [A|B], [A|BRes]) :-
	pguc_simplify_body(PGUCs, B, BRes).

%% Is H :- B a positive ground unit clause?
pguc([H] :- []) :- ground(H).

non_pguc(C) :- \+ pguc(C).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

make_equations([], [], []).
make_equations([X1|R1], [X2|R2], [X1=X2|RRes]) :-
	make_equations(R1, R2, RRes).

make_N_variables(0, []).
make_N_variables(N, [_X|R]) :-
	M is N - 1,
	make_N_variables(M, R), !.

%% add_arguments(T, Args, Res)
%% For each term in Args, add it as the last argument to the (function) term
%% T, collect the result in the list Res
add_arguments(_T, [], []).
add_arguments(T, [Arg|R], [TArg|RRes]) :-
	add_argument(T, Arg, TArg),
	add_arguments(T, R, RRes).

add_argument(T, Arg, TArg) :-
	T =.. [F|Args],
	append([F|Args], [Arg], H),
	TArg =.. H.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

prepend_atoms_predsyms([], _Prefix, [], []).
prepend_atoms_predsyms([A|R], Prefix, [PrefixA|PrefixR], Sig) :-
	A =.. [Pred|Args],
	concat_atom([Prefix,Pred], PrefixPred),
	PrefixA =.. [PrefixPred|Args],
	prepend_atoms_predsyms(R, Prefix, PrefixR, RSig),
	length(Args, Arity),
	( member(Pred/Arity, RSig) ->
	    Sig = RSig
	; Sig = [Pred/Arity|RSig]
        ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

scan_function_symbols(CS, FS) :-
	findall(TSigs,
	  ( member(C, CS),
	    clause_atoms(C, AL),
	    terms_args_union(AL, TL),
	    function_symbols_list(TL, TSigs)
	  ),
	  HL),
	  %% Have a list of lists of fun/arity, flatten it
	  append(HL, H),
	  list_to_set(H, FS).
	  
function_symbols_list([], []).
function_symbols_list([T|R], RRes) :-
	( var(T) ; number(T) ), !,
	function_symbols_list(R, RRes).
function_symbols_list([T|R], Res) :-
	    nonvar(T), 
	    T =.. [Fun|Args],
	    length(Args, Arity),
	    function_symbols_list(Args, ArgsRes),
	    function_symbols_list(R, RRes),
	    append([Fun/Arity|ArgsRes], RRes, Res).

scan_predicate_symbols(CS, PS) :-
	findall(Pred/Arity,
	  ( member(C, CS),
	    clause_atoms(C, AL),
	    member(A, AL),
	    A =.. [Pred|Args],
	    length(Args, Arity)
	  ),
	  PSH),
	  list_to_set(PSH, PS).


dom_functors_list([], []).
dom_functors_list([T|R], RRes) :-
	( var(T) ; number(T) ), !,
	dom_functors_list(R, RRes).
dom_functors_list([T|R], [Dom|RRes]) :-
	    T =.. [Dom|_Args],
	    concat_atom([dom_,_],Dom), 	    %% have the "dom_" prefix?
	    !, 
	    %% No need to recurse into the _Args
	    dom_functors_list(R, RRes).
dom_functors_list([T|R], Res) :-
	    %% T is not made with a dom_ functor
	    T =.. [_Fun|Args],
	    dom_functors_list(Args, ArgsRes),
	    dom_functors_list(R, RRes),
	    append(ArgsRes, RRes, Res).


scan_dom_functors(CS, DS) :-
	findall(CDomFunctors,
	  ( member(C, CS),
	    clause_atoms(C, AL),
	    dom_functors_list(AL, CDomFunctors)
	  ),
	  HDomFunctors),
	  %% Have a list of lists of fun/arity, flatten it
	  append(HDomFunctors, DomFunctors),
	  list_to_set(DomFunctors, DS).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Select all atoms from a list that are built with a given predicate symbol:
p_atoms([], _P, []).
p_atoms([A|R], P, [A|RRes]) :-
	A =.. [P|_Args], !,
	p_atoms(R, P, RRes).
p_atoms([_A|R], P, RRes) :-
	p_atoms(R, P, RRes).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	
