%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% Flattening
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(flattening, [flatten_clause_set/2, simplify/2]).

:- use_module('/home/users/baumgart/prover/yarralumla/misc').
:- use_module('/home/users/baumgart/prover/yarralumla/data_structures').

flatten_clause_set(CS, [([X=X] :- [])|CSA]) :-
	%% Notice we add reflexivity.
	%% This gives us a complete transformation for the case
	%% that the input does not contains equality.
	maplist(flatten_clause, CS, CSAL),
	%% Have a list of list of clauses now, flatten it:
	append(CSAL, CSA).


flatten_clause((H :- B), [HFlat :- BRes]) :-
	nb_getval(flattening_option, standard),
	%% H :- B is a list clause.
	%% Notice the result is a singleton.
	( nb_getval(flattenhead_option, true) ->
	    flatten_list(H, HFlat, HDefs)
	; HFlat = H,
	  HDefs = []
        ),
	flatten_list(B, BFlat, BDefs),
	append([BFlat, HDefs, BDefs], BRes).

flatten_clause((H :- B), Res) :-
	nb_getval(flattening_option, separation),
	%% H :- B is a list clause.
	%% Separate away the definitions for the extracted subterms
	%% Notice this is not done recursively
	%% (for lazyness reasons; also it will not be needed in practice (?)).
	( nb_getval(flattenhead_option, true) ->
	    flatten_list(H, HFlat, HDefs)
	; HFlat = H,
	  HDefs = []
        ),
	flatten_list(B, BFlat, BDefs),
	%% Now separate away the HDefs and BDefs instead of integrating
	%% them into the clause body.
	%% Start with the head:
	term_variables((HFlat :- BFlat), Vars),
	term_variables(HDefs, HDefsVars),
	intersectq(Vars, HDefsVars, HDefsCommonVars),
	gensym(head_def_, HDefsSepPred),
	HDefsSepAtom =.. [HDefsSepPred|HDefsCommonVars],
	%% The same for the body:
	term_variables(BDefs, BDefsVars),
	intersectq(Vars, BDefsVars, BDefsCommonVars),
	gensym(body_def_, BDefsSepPred),
	BDefsSepAtom =.. [BDefsSepPred|BDefsCommonVars],
	%% Now some sanity check: if the separated clause is a unit clause
	%% there is no point in separating it away. 
	%% (In fact, it must be a ground clause then.)
	%% Get rid of it by unit resolution:
        HRes = [(HFlat :- [HDefsSepAtom, BDefsSepAtom | BFlat]),
               ([HDefsSepAtom] :- HDefs),
               ([BDefsSepAtom] :- BDefs)],
        simplify(HRes, Res).
		      

%% flatten(A, AFlat, ADefs)
%% Flatten an atom A, yielding the atom AFlat and a set of 
%% definitions (equations) ADefs for the extracted subterms, 
%% which are all flat, too.

flatten(S=T, SFlat=TFlat, STDefs) :- !,
	( nb_getval(flattenequations_option, true) ->
	    %% For an equation to be flat, both sides have to be flat terms
	    flatten_term(S, SFlat, SDefs),
	    flatten_term(T, TFlat, TDefs),
	    append(SDefs, TDefs, STDefs)
	; SFlat=S, 
	  TFlat=T, 
	  STDefs=[]
        ).


%% Usual flattening, in particular when flattenequations_option is false
flatten(A, AFlat, ADefs) :-
	nb_getval(flattentoplevel_option, true), 
 	flatten_term(A, AFlat, ADefs).	

%% Keep the topmost terms:
flatten(A, AFlat, ADefs) :-
	A =.. [Pred|Args],
	flatten_term_list(Args, ArgsFlat, ADefs),
	AFlat =.. [Pred|ArgsFlat].

flatten_term_list([], [], []).
flatten_term_list([T|R], [TFlat|RFlat], TRDefs) :-
	flatten_term(T, TFlat, TDefs),
	flatten_term_list(R, RFlat, RDefs),
	append(TDefs, RDefs, TRDefs).


flatten_term(N, N, []) :- 
	%% Just allow numbers in the input
	number(N), !.

flatten_term(X, X, []) :- 
	var(X), !.

flatten_term(A, AFlat, ADefs) :-
	%% Flatten a (compound) term 
	A =.. [Pred|Args],
	flatten_term_args(Args, ArgsFlat, ADefs),
	AFlat =.. [Pred|ArgsFlat].

flatten_term_args([], [], []).

flatten_term_args([X|R], [X|RFlat], RDefs) :- 
	%% Nothing to do when flattening a variable
	var(X), !,
	flatten_term_args(R, RFlat, RDefs).

flatten_term_args([T|R], [T|RFlat], RDefs) :- 
	%% Nothing to do when flattening a constant and option
	%% says we should leave it in place.
	atomic(T), 
	nb_getval(flatteningextractconstants_option, false), !,
	flatten_term_args(R, RFlat, RDefs).


flatten_term_args([T|R], [X|RFlat], TRDefs) :- 
	%% Extract the term T, because it is not a variable
	flatten(T=X, TFlat=X, TDefs),
	flatten_term_args(R, RFlat, RDefs),
	append([TFlat=X| TDefs], RDefs, TRDefs).

%% lifting of flatten/3 to lists:
flatten_list([],[],[]).
flatten_list([A|R], [AFlat|RFlat], ARDefs) :-
	flatten(A, AFlat, ADefs),
	flatten_list(R, RFlat, RDefs),
	append(ADefs, RDefs, ARDefs).


