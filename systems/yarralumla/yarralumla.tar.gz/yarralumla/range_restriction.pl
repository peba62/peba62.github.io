%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% Separation
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(rangerestriction, 
	[rr_clause_set/2,
	rr_clause/2
     ]).

:- use_module('/home/users/baumgart/prover/yarralumla/misc').
:- use_module('/home/users/baumgart/prover/yarralumla/data_structures').
%% :- use_module('/home/users/baumgart/prover/yarralumla/sorting').


rr_clause_set(CSH, Res) :-
	%% Add reflexivity - it is the only equality axiom that
	%% will be modified by the transformation
	%% CS = [([X=X]:-[dom(X)])|CSH],
	CS = CSH,
	%% (1) add a constant if none is there
 	scan_function_symbols(CS, FSig),
	( member(AConstant/0, FSig) ; AConstant = a_constant ),
	Res1 = [([dom(AConstant)] :- [])],
	%% (2) Make the clauses that insert new domain elements for
	%% atoms derived. These clauses are based on the signature:
 	scan_predicate_symbols(CS, CSPSig),
	%% Now make these clauses:
 	domain_elements_axioms_from_sig(CSPSig, Res2),
	%% There is a potential problem with equality:
	%% dom(X) :- X=Y.
	%% dom(Y) :- X=Y.
	%% which will be simplified by MSPASS to 
	%% dom(X).
	%% And this is unusable for us.
	%% Solution: use MSPASS flags -IEqR=0 -RInput=1 -IORe=2
	%%
	%% (3) Make the clauses that insert remaining new domain elements.
	%% These clauses insert domain elements depending from the
	%% terms in the body:
	maplist(domain_elements_axioms_from_clause_body, CS, DomElemAxioms3L),
	%% Have a list of lists, thus flatten ...
	append(DomElemAxioms3L, DomElemAxioms3),
	%% ... and range-restrict:
	maplist(rr_clause, DomElemAxioms3, Res3),
	%%
	%% (3) Range-restrict the given clause set:
	maplist(rr_clause, CS, Res4),
	%% Add clauses to make with each term its subterms domain elements,
	%% too:
 	dom_subterm_clauses(FSig, Res5),
	%% Finally collect the grand result:
	append([Res1, Res2, Res3, Res4, Res5], Res).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rr_clause((H :- B), (H :- BDom)) :-
	term_variables(H, HVars),
	term_variables(B, BVars),
	%% For *extra* variables  ...
	subtractq(HVars, BVars, HDomVars), 
	%% and for variables occuring in body equations:
	%% no - no longer:
%%   	p_atoms(B, (=), BEquations),
%%   	term_variables(BEquations, BEquationsVars),
%%   	unionq(HDomVars, BEquationsVars, DomVars),
	make_doms(HDomVars, DomVarsDom),
	append(B, DomVarsDom, BDom).

make_doms([],[]).
make_doms([X|R],[dom(X)|DomR]) :- make_doms(R,DomR).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% domain_elements_axioms_from_clause_body((_H :- B), Res)
%% Make clauses to insert domain elements depending from the
%% terms in the body:

domain_elements_axioms_from_clause_body((_H :- B), Res) :-
	%% Make the clauses to insert the terms 
	%% occuring in the body.
	maplist(domain_elements_axioms_from_body_lit, B, 
	             InsertDomElementsClauses1),
	%% Have a list of list clauses, thus flatten:
	append(InsertDomElementsClauses1, Res).

/*
 * Doesn't work!
 *
domain_elements_axioms_from_body_lit(A, Res) :-
	nb_getval(a_constant, AConstant),
	abstract_atom(A, AAbst, Subst), 
	findall(([dom(T)] :- [AAbst]),
	        ( member(X/T, Subst),
		  nonvar(T),
		  X = AConstant
	        ),
		Res).
 */

domain_elements_axioms_from_body_lit(A, Res) :-
	abstract_atom(A, AAbst, Subst), 
	findall(([dom(T)] :- [AAbst]),
	        ( member(_X/T, Subst),
		  nonvar(T)
	        ),
		Res).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% domain_elements_axioms_from_terms(Terms, Body, Res)
%% Terms is a list of terms.
%% Res is a list of clauses with
%% heads dom(T) and body Body, for each term T in Terms.

domain_elements_axioms_from_terms([], _Body, []).
domain_elements_axioms_from_terms([T|R], Body, [([dom(T)] :- Body)|RRes]) :-
	domain_elements_axioms_from_terms(R, Body, RRes).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

domain_elements_axioms_from_sig(PredSymbs, DomElAxioms) :-
	maplist(domain_elements_axioms_from_sig_1, PredSymbs, DomElAxiomsL),
	append(DomElAxiomsL, DomElAxioms).

domain_elements_axioms_from_sig_1(P/N, Res) :-
	make_N_variables(N, Vars),
	PBody =.. [P|Vars],
	domain_elements_axioms_from_sig_2(Vars, [PBody], Res).

domain_elements_axioms_from_sig_2([], _Body, []).
domain_elements_axioms_from_sig_2([X|Res], Body, [([dom(X)] :- Body)|RRes]) :-
	domain_elements_axioms_from_sig_2(Res, Body, RRes).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dom_subterm_clauses(Sig, Res) :-
	%% Sig is a list of function symbols plus arities (F/N)
	maplist(dom_subterm_clauses_1, Sig, HRes),
	%% Have a list of lists now, flatten it
	append(HRes, Res).

dom_subterm_clauses_1(F/N, Res) :-
	%% See example below to make sense of this
	make_N_variables(N, NXVars),
	FNXVars =.. [F|NXVars],
	findall(([dom(X)] :- [dom(FNXVars)]),
	        member(X, NXVars),
		Res).

/*
 * Example:

dom(X1) :- dom(g(X1,X2)).
dom(X2) :- dom(g(X1,X2)).

 */

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

abstract_atom(A, ARes, Subst) :-
	A =.. [P|Args],
	abstract_arg_list(Args, [], ArgsRes, _NewVarsSoFar, Subst),
	ARes =.. [P|ArgsRes].

%% abstract_arg_list(Args, VarsSoFar, ArgsRes, NewVarsSoFar, ArgsSubst):
abstract_arg_list([], VarsSoFar, [], VarsSoFar, []).
abstract_arg_list([X|R], VarsSoFar, [X|RAbst], NewVarsSoFar, RSubst) :-
	%% If X is a variable that has not occured before then it may remain:
	%% var(X),	\+ memberq(X, VarsSoFar), !,
	%% Alternative: all variables may remain:
	var(X),	
	%% Just go on with the rest, but remember X is present now:
	abstract_arg_list(R, [X|VarsSoFar], RAbst, NewVarsSoFar, RSubst).
abstract_arg_list([T|R], VarsSoFar, [X|RAbst], NewVarsSoFar, [(X/T)|RSubst]) :-
	%% In all other cases the term T has to be replaced by a fresh 
	%% variable, which we call X here.
	%% (No need to remember X, as it is fresh anyways)
	abstract_arg_list(R, VarsSoFar, RAbst, NewVarsSoFar, RSubst).

