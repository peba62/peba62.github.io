:- module(misc, 
	[msg/1, msg/2,
	 append/2,
	 intersectq/3,
	 memberq/2,
	 member2/4,
	 subtractq/3,
	 unionq/3,
	 replaceq/4,
	 set_create/1,
	 set_add/2,
	 set_members/2,
	 set_member/2,
	 remember_functor/2,
	 remember_functors/2
    ]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

msg(Msg) :-
	msg(Msg, []).
msg(Msg, Args) :-
%%	write(user_error, '% Yarralumla: '),
%%	write(user_error, '% '),
	format(user_error, Msg, Args),
	nl(user_error),
	flush_output(user_error).

%% concatenate all lists given in the first argument
append([], []).
append([L| R], Res) :-
	append(R, H),
	append(L, H, Res).

%% Some operations on sets. 
%% The "q" shall indicate the use of "==" (instead of unification, "=").
%% Thus, no instantiation of variables happens.

intersectq([], _, []).

intersectq([Element|Residue], Set, Result) :-
        memberq(Element, Set),
        !,                    
        Result = [Element|Intersection],
        intersectq(Residue, Set, Intersection).

intersectq([_|Rest], Set, Intersection) :-
        intersectq(Rest, Set, Intersection).

memberq(HArg,[Arg|_]) :-
        HArg == Arg, !.
memberq(Arg,[_|Tail]) :-
        memberq(Arg,Tail).

% subtractq(L1, L2, L3)
% L3 = L1 - L2

subtractq([], _, []).
subtractq([Head|L1tail], L2, L3) :-
        memberq(Head, L2),
        !,
        subtractq(L1tail, L2, L3).
subtractq([Head|L1tail], L2, [Head|L3tail]) :-
        subtractq(L1tail, L2, L3tail).

unionq([], Set2, Set2).
unionq([Element|Residue], Set, Union) :-
       memberq(Element, Set), !,
       unionq(Residue, Set, Union), !.
unionq([Element|Residue], Set, [Element|Union]) :-
       unionq(Residue, Set, Union).

replaceq([], _Old, _New, []).
replaceq([F|R], Old, New, [New|RRes]) :-
	F == Old,
	replaceq(R, Old, New, RRes).
replaceq([F|R], Old, New, [F|RRes]) :-
	\+ F == Old,
	replaceq(R, Old, New, RRes).




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

set_create(SetName) :-
	nb_setval(SetName, []).

set_add(SetName, El) :-
	nb_getval(SetName, Current),
	( member(El, Current) ->
	    true
	; nb_setval(SetName, [El|Current])
        ).

set_members(SetName, Current) :-
	nb_getval(SetName, Current).

set_member(SetName, El) :-
	nb_getval(SetName, Current),
	member(El, Current).


%%%%%%%%%%%

remember_functor(Set, P/N) :-
	set_add(Set, P/N).

remember_functors(_Set, []).
remember_functors(Set, [P/N|R]) :-
	remember_functor(Set, P/N),
	remember_functors(Set, R).


member2(X1, X2, [X1|_], [X2|_]).
member2(X1, X2, [_|R1], [_|R2]) :-
	member2(X1, X2, R1, R2).


%%%%%%%%%%%


