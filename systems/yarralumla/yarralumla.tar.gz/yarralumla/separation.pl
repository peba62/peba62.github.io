%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% Separation
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(separation, 
	[separation_clause_set/2
     ]).

:- use_module('/home/users/baumgart/prover/yarralumla/misc').
:- use_module('/home/users/baumgart/prover/yarralumla/data_structures').

%% (User) option: the 'abstraction_protected' procedure
%% Used in 'abstract_and_separate' below (cf. documentation there).

abstraction_protected(_) :-
	%% Don't abstract anything -- i.e. switch off separation
	nb_getval(separation_option, none).
abstraction_protected(_=_) :-
	%% Don't abstract away equations.
	nb_getval(separation_option, nonequations).
abstraction_protected(_) :- 
	%% the whole body is abstracted
	nb_getval(separation_option, full),
	!, fail. 

separation_clause_set(CS, Res) :-
	%% First separate:
	maplist(separation_clause, CS, CSSepL),
	%% Have a list of list of list clauses, thus flatten:
	append(CSSepL, Res).

separation_clause((H :- B), Res) :-
	%% First, abstraction and separation of H :- B.
	%% This amounts to building the two "separation clauses"
	%% that resolve to the original clause H :- B.

	%% First we separate and abstract the clause body:
	abstract_and_separate(B, BAbst, BProtected, BAbstName, BAbstSubst),
	%% The abstracted body BAbst is named by BAbstName 
	%% (an atom, parametrized with at least the variables of BAbst)
	%% The clause [BAbstName] :- BAbst *is* range-restricted
	%% if "Code Alternative 2" is chosen below in
	%% abstract_and_separate. We don't assume that, though.
	SeparationClause1 = ([BAbstName] :- BAbst),
	%% Instantiate in BAbstName the abstraction variables back with 
	%% the terms: 
	apply_subst(BAbstSubst, BAbstName, BAbstNameInst),
	%% We need this to construct the second clause, 
	%% the clause with the original head H as its conclusion, 
	%% and this clause is just H :- [BAbstNameInst|BProtected].
	SeparationClause2 = (H :- [BAbstNameInst|BProtected]), 
	%% 
	%% Finally, compute the results:
	simplify([SeparationClause1, SeparationClause2], Res).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% abstract_and_separate(B, BAbst, BProtected, AbstName, Subst)
%% BAbst is an abstracted version of those atoms of B (a clause body)
%% that don't classify as abstraction_protected. In BAbst, 
%% - all terms are variables
%% - no variable occurs more than once in BAbst.
%% The non-abstracted atoms of B are returned in BProtected.
%% AbstName is a new name for BAbst, i.e. a fresh atom containing
%% at least the variables in BAbst.
%% Subst is a list of pairs X/T where X is a variable and T is a term
%% that, when applied (as a substitution) to BAbstFinal yields B again.

abstract_and_separate(B, BAbst, BProtected, AbstName, Subst) :-
	%% little wrapper:
	abstract_and_separate_helper(B, [], BAbst, BProtected, Subst),
	%% Construct a new name for the abstracted body:
	gensym(abst_def_, AbstPred),

%% Code Alternative 1:

        %% This is close to Renate's suggestion about abstraction
        %% and separation.
        %% Don't use it currently , because it may results in 
	%% a non-range-restricted clause
        %% that is difficult to supply with sorts.

	%% The abstraction name depends on the variables in B ...
%%	term_variables(B, BVars),
	%% .. and the freshly introduced variables in the abstraction.
	%% The easiest way to get hold of these is just by the domain 
	%% of Subst: 
%%	subst_domain(Subst, SubstDomain),
%%	append(SubstDomain, BVars, AllVars),
	%% Notice AllVars contains *at least* the variables of BAbst,
	%% the abstracted body, but extra variables may have come in 
	%% by abstracting away terms from B, 
	%% as e.g. the term f(X) in the body of p(Y) :- f(X)=Y.  (*)
	%% In this example abstraction of the body results in the 
	%% abstracted body U=Y, Subst is [U/f(X)] and AllVars is [U,X,Y].
	%%
	%% Now we can make the new name for the abstraction:
%%	AbstName =.. [AbstPred|AllVars].
	%% By the just said AbstName may contain more (i.e. extra) variables
	%% than BAbst. Therefore the clause [AbstName] :- BAbst
	%% is possibly not range-restricted. 

%% Code Alternative 2:

        %% The abstraction depends on the variables in BAbst *only*:
	term_variables(BAbst, BAbstVars),
	AbstName =.. [AbstPred|BAbstVars].
	%% Now the clause [AbstName] :- BAbst
	%% *is* range-restricted. 
	%% This alternative seems advantageous as it leads to 
	%% fewer parameters, and the sorted case is easier to cope with:
	%% by range-restrictedness we don't have to worry what would be
	%% the right sorted domain predicates to generate.
	%% Not sure though if that all is optimal ... (Renate ?)

abstract_and_separate_helper([], _VarsSoFar, [], [], []).
abstract_and_separate_helper([A|R], VarsSoFar, [AAbst|RAbst], RProtected, Subst) :-
	\+ abstraction_protected(A), !, 
	A =.. [P|Args],
	abstract_arg_list_for_separation(Args, VarsSoFar, ArgsRes, NewVarsSoFar, ArgsSubst),
	AAbst =.. [P|ArgsRes],
	abstract_and_separate_helper(R, NewVarsSoFar, RAbst, RProtected, RSubst),
	append(ArgsSubst, RSubst, Subst).
abstract_and_separate_helper([A|R], VarsSoFar, RAbst, [A|RProtected], Subst) :-
	%% In the abstraction_protected case just move A to the 'proteced' part
	abstract_and_separate_helper(R, VarsSoFar, RAbst, RProtected, Subst).

abstract_arg_list_for_separation([], VarsSoFar, [], VarsSoFar, []).
abstract_arg_list_for_separation([X|R], VarsSoFar, [X|RAbst], NewVarsSoFar, RSubst) :-
	%% If X is a variable that has not occured before then it may remain:
	var(X),	\+ memberq(X, VarsSoFar), !,
	%% Just go on with the rest, but remember X is present now:
	abstract_arg_list_for_separation(R, [X|VarsSoFar], RAbst, NewVarsSoFar, RSubst).
abstract_arg_list_for_separation([T|R], VarsSoFar, [X|RAbst], NewVarsSoFar, [(X/T)|RSubst]) :-
	%% In all other cases the term T has to be replaced by a fresh 
	%% variable, which we call X here.
	%% (No need to remember X, as it is fresh anyways)
	abstract_arg_list_for_separation(R, VarsSoFar, RAbst, NewVarsSoFar, RSubst).

