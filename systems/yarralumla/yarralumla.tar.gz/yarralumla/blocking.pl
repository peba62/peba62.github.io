%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% Blocking
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(range_restriction, 
	[blocking_clause_set/2
     ]).

:- use_module('/home/users/baumgart/prover/yarralumla/misc').
:- use_module('/home/users/baumgart/prover/yarralumla/data_structures').


blocking_clause_set(CS, Res) :-
	scan_function_symbols(CS, FSig),
	subterm_clauses(FSig, SubtermClauses),
%% 	scan_predicate_symbols(CS, PSig),
%% 	speculate_equality_clauses(PSig, EQClauses),
%% No! It is enough to 'check loops' on the domain-predicates alone:
%% If there is no loop through the domain predicates, there is no loop
%% at all:
 	speculate_equality_clauses([dom/1], EQClauses),
	append([CS,SubtermClauses,EQClauses], Res).


subterm_clauses(Sig, [([subterm(X,X)] :- [dom(X)])|Res]) :-
	%% Sig is a list of function symbols plus arities (F/N)
	maplist(subterm_clauses_, Sig, HRes),
	%% Have a list of lists now, flatten it
	append(HRes, Res).

subterm_clauses_(F/N, Res) :-
	%% See example below to make sense of this
	make_N_variables(N, NVars),
	FNVars =.. [F|NVars],
	findall(([subterm(X,FNVars)] :- 
                        [subterm(X,Y), dom(X), dom(FNVars)]),
	        member(Y, NVars),
		Res).

speculate_equality_clauses(Sig, [([] :- [(Y=X), nonequal(Y,X)])|Res]) :-
	%% Sig is a list of function symbols plus arities (F/N)
	maplist(speculate_equality_clauses_, Sig, HRes),
	%% Have a list of lists now, flatten it
	append(HRes, Res).

speculate_equality_clauses_(F/N, Res) :-
	make_N_variables(N, NXVars),
	make_N_variables(N, NYVars),
	FNXVars =.. [F|NXVars],
	FNYVars =.. [F|NYVars],
	findall(([Y=X, nonequal(Y,X)] :- [FNXVars, FNYVars, subterm(X,Y)]),
	        member2(X, Y, NXVars, NYVars),
		Res).
	

/*
 * Example:

subterm(X,X) :- dom(X).

subterm(X,f(Y)) :- subterm(X,Y), dom(X), dom(f(Y)).

subterm(X,g(Y1,Y2)) :- subterm(X,Y1), dom(X), dom(g(Y1,Y2)).
subterm(X,g(Y1,Y2)) :- subterm(X,Y2), dom(X), dom(g(Y1,Y2)).

false :- Y=X, nonequal(Y,X).

Y1=X1 ; nonequal(Y1,X1) :- r(X1,X2), r(Y1,Y2), subterm(X1,Y1).
Y2=X2 ; nonequal(Y2,X2) :- r(X1,X2), r(Y1,Y2), subterm(X2,Y2).


 */